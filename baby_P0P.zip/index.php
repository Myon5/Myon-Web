<?php
show_source(__FILE__);
class apache{
    public $lin;
    public function __toString(){
        $this->lin->check();
        return '';
    }
}
class tomcat{
    public $drew;
    public function __get($name) {
        ($this->drew)();
    }
}
class nginx{
    private $pay;
    private $par;
    public function check() {
        if (!preg_match("/(cat|tac|flag)|\/[^\/]*\/|\s+|(\.\.\/)/i", $this->par)) {
            ($this->pay)($this->par);
        }else{
            die("勇师傅察觉到你的参数不对劲");
        }
    }
}
class eva1{
    public $old;
    public $new;
    public function __wakeup() {
        $this->old->new;
    }
}
class iis {
    public $kha="hello myon!";
    public function __invoke(){
        ucwords($this->kha);
    }
}
unserialize(base64_decode($_GET['snert']));

?>
