<?php
$flag = "flag{BreAk_tHe_c1rcLe_anD_StAnd!}";
?>