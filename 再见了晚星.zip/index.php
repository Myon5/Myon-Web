<?php

show_source(__FILE__);
ini_set('display_errors', 0);
error_reporting(0);
include('flag.php');

$str = $_GET['M_Y'] ?? 'hello!';

if (strpos($_SERVER["QUERY_STRING"], "M_Y") !==FALSE) {
    echo 'NONE';
}

elseif ($str<1111111111111111111) {
    echo 'M_Y,太小啦';
}
elseif ((string)$str>0) {
    echo 'M_Y,太大咯';
}
else {
    echo $flag1;
}

if (isset($_POST['M'])&&isset($_POST['Y'])){
$O=is_numeric($_POST['M']) and is_numeric(($_POST['Y']));

if($O) {
    $N = (string)$_POST['Y'];

if (preg_match('/.+?myon/is', $N)) {
    die("再见很容易");
    }

if (stripos($N, 'swctfmyonsnert') === FALSE) {
    die("再见却很难");
 }
else{
    echo $flag2;
    }
 }
}

?>