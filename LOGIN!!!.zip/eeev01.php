<?php
show_source(__FILE__);
ini_set('display_errors', 0);
error_reporting(0);
include('myon3.php');
$myon3 = @$_GET['hack'];
eval("var_dump($$myon3);")
?>