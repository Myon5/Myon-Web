<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Network Security Quiz</title>
    <style>
        body {
            background-image: url('cs.png');
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        form {
            padding: 20px;
            background-color: transparent;
            border-radius: 10px;
        }
        p {
            margin-bottom: 10px;
        }
        input[type="radio"] {
            margin-right: 10px;
        }
        input[type="submit"] {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        p.result {
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }
        p.no-result {
            text-align: center;
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Network Security Quiz</h1>
    <form method="post">
        <p>1. 在Linux下查看ip地址使用命令ipconfig。 (True/False)</p>
        <label><input type="radio" name="q1" value="True"> True</label>
        <label><input type="radio" name="q1" value="False"> False</label>

        <p>2. Struts 2如果开启altSyntax会支持对标签中的 OGNL 表达式进行解析并执行。 (True/False)</p>
        <label><input type="radio" name="q2" value="True"> True</label>
        <label><input type="radio" name="q2" value="False"> False</label>

        <p>3. SQL 注入只能通过select into out file来写入webshell。 (True/False)</p>
        <label><input type="radio" name="q3" value="True"> True</label>
        <label><input type="radio" name="q3" value="False"> False</label>

        <p>4. 在Windows中可以使用schtasks命令查看启动项。 (True/False)</p>
        <label><input type="radio" name="q4" value="True"> True</label>
        <label><input type="radio" name="q4" value="False"> False</label>

        <p>5. CSRF跨站请求伪造由服务端发起。 (True/False)</p>
        <label><input type="radio" name="q5" value="True"> True</label>
        <label><input type="radio" name="q5" value="False"> False</label>

        <p>6. benchmark函数用于布尔盲注，sleep函数用于时间盲注。 (True/False)</p>
        <label><input type="radio" name="q6" value="True"> True</label>
        <label><input type="radio" name="q6" value="False"> False</label>

        <p>7. 常见的报错注入函数有：updatexml 、 extractvalue、floor。 (True/False)</p>
        <label><input type="radio" name="q7" value="True"> True</label>
        <label><input type="radio" name="q7" value="False"> False</label>

        <p>8. 常见的JNDI 协议地址有"ldap://"、"rmi://"，可用于加载远程恶意脚本。 (True/False)</p>
        <label><input type="radio" name="q8" value="True"> True</label>
        <label><input type="radio" name="q8" value="False"> False</label>

        <p>9. IPS是被动防御，而IDS是主动防御，会预先对攻击活动或入侵性网络流量进行拦截。 (True/False)</p>
        <label><input type="radio" name="q9" value="True"> True</label>
        <label><input type="radio" name="q9" value="False"> False</label>

        <p>10. jwt是Js Web Token 的缩写。 (True/False)</p>
        <label><input type="radio" name="q10" value="True"> True</label>
        <label><input type="radio" name="q10" value="False"> False</label>

        <input type="submit" value="Submit">
    </form>
    <?php
    // 答案数组
    $answers = array(
        "q1" => "False",
        "q2" => "True",
        "q3" => "False",
        "q4" => "False",
        "q5" => "False",
        "q6" => "False",
        "q7" => "True",
        "q8" => "True",
        "q9" => "False",
        "q10" => "False"
    );

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $has_error = false;

        // 检查每个问题的答案
        foreach ($answers as $question => $correct_answer) {
            if (!empty($_POST[$question])) {
                $user_answer = $_POST[$question];
                if ($user_answer !== $correct_answer) {
                    $has_error = true;
                    break;
                }
            } else {
                $has_error = true;
                break;
            }
        }

        // 如果有任何错误，输出 "no~"
        if ($has_error) {
            echo "<p class='no-result'>no~</p>";
        } else {
            echo "<p class='result'>Secret: ll0g1n.html   eeev01.php</p>";
        }
    }
    ?>
</div>
</body>
</html>
