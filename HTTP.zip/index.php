<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HTTP签到题</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: url('test.png') center/cover no-repeat;
        }

        .container {
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
        }

        h1 {
            color: #3498db;
        }

        p {
            font-size: 18px;
            margin-top: 20px;
            color: #555;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>HTTP签到题</h1>
    <p>Flag就在首页</p>
    <p>Good Luck!</p>
</div>
</body>
<script>
    window.location.href="index.html";
</script>
<!--flag{Y0u_ar2_RiGHT_careful_br0}-->
</html>
