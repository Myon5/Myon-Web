<?php

// flag is in flag.php
highlight_file(__FILE__);
ini_set('display_errors', 0);
error_reporting(0);

if (isset($_GET['myon1']) && isset($_GET['myon2']) && isset($_GET['myon3'])) {
    $myon1 = $_GET['myon1'];
    $myon2 = $_GET['myon2'];
    $myon3 = $_GET['myon3'];

    if (file_get_contents($myon1) === "hello Myon!") {
        echo "welcome!";
    } else {
        echo "you can't see the flag!";
    }

    if (stripos($myon2, "flag") !== false || preg_match("/flag/i", $myon2)) {
        die("Access denied!");
    } else {
        include($myon2);  // myon.php
        $my = unserialize($myon3);
        echo $my;
    }
}

?>


