<?php
class Myon{
    public $myon;
    public function __toString(){
        if(isset($this->myon)){
            echo file_get_contents($this->myon);
        }
    }
}
