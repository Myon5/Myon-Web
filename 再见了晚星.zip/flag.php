<?php
$flag1 = "flag{ThInk_cOnstantly_0f_";
$flag2 = "There_w1ll_be_n0_echO}";
