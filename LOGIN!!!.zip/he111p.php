<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Key</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('h.png');
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-top: 0;
            text-align: center;
        }
        form {
            text-align: center;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        p {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>请输入 key：</h2>
        <form action="" method="get">
            <input type="text" name="key" placeholder="Enter your key...">
            <br>
            <input type="submit" value="提交">
        </form>
        <br>
        <?php
        // 判断是否有提交的 key
        if(isset($_GET['key'])){
            // 获取提交的 key
            $key = $_GET['key'];

            // 判断 key 是否严格等于指定值
            if ($key === '@hAve_fUn_w1Th_JavaScript!loveis_f') {
                echo '<p>@l0g1n_s0urce.swp</p>';
            } else {
                echo '<p>i dont know you!</p>';
            }
        }
        ?>
    </div>
<!-- key = myon3 + (((myon1.toUpperCase()).substring(2, 6) + myon2.substring(7, 11)).toLowerCase()).substring(0, 28) -->
</body>
</html>
