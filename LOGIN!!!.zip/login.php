<?php
// 假设这是你的用户验证逻辑，这里是一个简单的示例
$validUsername = 'toor';
$validPassword = strval(rand(1000000000, 9999999999)); // 生成一个 10 位随机数作为密码

// 获取 POST 数据
$postData = json_decode(file_get_contents('php://input'), true);

// 检查用户名是否正确
$username = $postData['username'];
if ($username !== $validUsername) {
    $response = array('success' => false, 'message' => 'Invalid username!');
} else {
    // 检查密码
    $password = $postData['password'];
    if (is_numeric($password)) {
        // 如果密码是数字，则逐位比较
        if ($password == $validPassword) {
            // 检查 User-Agent 是否为指定值
            $userAgent = $_SERVER['HTTP_USER_AGENT'];
            if ($userAgent === 'MYON/2.0 (Windows NT 10.0; Win64; x64)') {
                $response = array('success' => true, 'message' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmbGFnIjoie215b242X2Jsb2dfY3Nkbl9uZXR9In0.AnXhydUNXKadN - Gr - knp6TXhHhrZhnIh035KXjihzeA');
            } else {
                $response = array('success' => false, 'message' => 'Incorrect password!', 'validPassword' => $validPassword);
            }
        } else {
            $response = array('success' => false, 'message' => 'Incorrect password!', 'validPassword' => $validPassword);
        }
    } elseif (is_array($password)) {
        // 如果密码是数组，则将数组的每个元素作为密码的一位逐位比较
        $validPasswordDigits = str_split($validPassword);
        if ($password == $validPasswordDigits) {
            // 检查 User-Agent 是否为指定值
            $userAgent = $_SERVER['HTTP_USER_AGENT'];
            if ($userAgent === 'MYON/2.0 (Windows NT 10.0; Win64; x64)') {
                $response = array('success' => true, 'message' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmbGFnIjoie215b242X2Jsb2dfY3Nkbl9uZXR9In0.AnXhydUNXKadN - Gr - knp6TXhHhrZhnIh035KXjihzeA');
            } else {
                $response = array('success' => false, 'message' => 'Incorrect password!', 'validPassword' => $validPassword);
            }
        } else {
            $response = array('success' => false, 'message' => 'Incorrect password!', 'validPassword' => $validPassword);
        }
    } else {
        // 其他情况返回密码错误和正确密码
        $response = array('success' => false, 'message' => 'Incorrect password!', 'validPassword' => $validPassword);
    }
}

// 返回 JSON 响应
header('Content-Type: application/json');
echo json_encode($response);
?>
